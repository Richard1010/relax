﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "timer.h"
#include <QtWidgets>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void loadCannons();
    void loadPlanes();
    void flyingAnimation();

    void generateDelays();
    int Next(int minValue, int maxValue) ;
    void loadBlueShots();
    void loadRedShots();
    void shoot();
    QLabel* getRandomPlane();
    QLabel* getRandomCannon();
    int getRandomPlaneShootDelay(int planeNumber);
    int getRandomCannonShootDelay(int planeNumber);
    void planeShootAnimation();
     void cannonShootAnimation();
    int calculatePlaneX(int plane);
    int calculatePlaneX(int plane, int delay);

public slots:
    void startGame();
    void resetGame();
    void flyingFinished();
    void planeTimerFinished();
    void cannonTimerFinished();
    void planeShootFinished();
    void cannonShootFinished();
private:
    Ui::MainWindow *ui;
    QLabel* theImage;
    QPixmap themePic;
    int cannonsNumber = 3;
    QLabel* cannonImage;
    QPixmap cannonPic;
    QLabel* cannonImage2;
    QLabel* cannonImage3;
    std::vector<QLabel*> cannonLabels;
    int planeNumber = 3;

    QLabel* planeImage;
    QPixmap planePic;
    QPixmap planePic2;
    QPixmap planePic3;
    QLabel* planeImage2;
    QLabel* planeImage3;
    std::vector<QLabel*> planeLabels;

    QLabel* blueShotImage;
    QPixmap blueShotPic;
    std::vector<QLabel*> blueShotLabels;

    QLabel* redShotImage;
    QPixmap redShotPic;

    std::vector<QLabel*> redShotLabels;

    QPushButton* startButton;
    QPushButton* resetButton;
    QPropertyAnimation* anim;
    QPropertyAnimation* anim2;
    QPropertyAnimation* anim3;
    Timer* planeTimer;
    Timer* cannonTimer;

};
#endif // MAINWINDOW_H
