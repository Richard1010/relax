#ifndef TIMER_H
#define TIMER_H

#include <QThread>

class Timer : public QThread
{
public:
    explicit Timer(QObject *parent = nullptr);

    void run();
    void setDelay(int delay);

public:
    int delay;
};

#endif // TIMER_H
