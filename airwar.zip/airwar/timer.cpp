#include "timer.h"

int delay;
Timer::Timer(QObject *parent) : QThread(parent)
{
}
void Timer::run(){
    QThread::msleep(delay);
}
void Timer::setDelay(int delay){
    this->delay = delay;
}

