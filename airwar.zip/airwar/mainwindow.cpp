﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtWidgets>
#include <QtConcurrent/QtConcurrent>


QString absPath = "";
QString startTheme = "/assets/background.jpg";
QString cannon = "/assets/cannon.jpg";
QString plane = "/assets/plane.jpg";
QString blueShot1 = "/assets/shotBlue1.jpg";
QString redShot1 = "/assets/shotRed1.jpg";

QFont serif("Century Gothic",10,QFont::Bold);
int delays[3];
bool running;
bool resetted;
int xC1 = 180;
int xC2 = 410;
int xC3 = 610;
int xP1 = 0;
int xP2 = 0;
int xP3 = 0;
int shootingPlane = -1;
int shootingCannon = -1;
int shootingPlaneDelay = 0;
int shootingCannonDelay = 0;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    absPath = QCoreApplication::applicationDirPath();

    startTheme = absPath+startTheme;

    theImage = new QLabel(this);

    themePic.load(startTheme);
    theImage->setPixmap(themePic);
    theImage->setGeometry((int)(0),(int)(0),(int) (800),(int)(600));

    loadCannons();
    loadPlanes();
    loadBlueShots();
    loadRedShots();

    startButton = new QPushButton(this);
    startButton->setGeometry((int)(750),(int)(500),(int) (50),(int)(20));
    startButton->setFont(serif);
    startButton->setText("Start");
    connect(startButton, &QPushButton::released, this, &MainWindow::startGame);

    resetButton = new QPushButton(this);
    resetButton->setGeometry((int)(750),(int)(550),(int) (50),(int)(20));
    resetButton->setFont(serif);
    resetButton->setText("Reset");
    connect(resetButton, &QPushButton::released, this, &MainWindow::resetGame);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::loadCannons(){

    cannon = absPath+ cannon;
    cannonPic.load(cannon);

    cannonImage = new QLabel(this);
    cannonImage->setPixmap(cannonPic);
    cannonImage->setObjectName("1");
    cannonImage->setGeometry((int)(170),(int)(450),(int) (80),(int)(80));

    cannonImage2 = new QLabel(this);
    cannonImage2->setObjectName("2");
    cannonImage2->setPixmap(cannonPic);
    cannonImage2->setGeometry((int)(400),(int)(450),(int) (80),(int)(80));

    cannonImage3 = new QLabel(this);
    cannonImage3->setObjectName("3");
    cannonImage3->setPixmap(cannonPic);
    cannonImage3->setGeometry((int)(600),(int)(450),(int) (80),(int)(80));

    cannonLabels.push_back(cannonImage);
    cannonLabels.push_back(cannonImage2);
    cannonLabels.push_back(cannonImage3);


}
void MainWindow::loadPlanes(){

    plane = absPath+ plane;
    planePic.load(plane);

    planeImage = new QLabel(this);
    planeImage->setPixmap(planePic);
     planeImage->setObjectName("1");
    planeImage->setGeometry((int)(750),(int)(30),(int) (80),(int)(80));

    planePic2.load(plane);
    planeImage2 = new QLabel(this);
    planeImage2->setPixmap(planePic2);
    planeImage2->setObjectName("2");
    planeImage2->setGeometry((int)(750),(int)(110),(int) (80),(int)(80));

    planePic3.load(plane);
    planeImage3 = new QLabel(this);
    planeImage3->setPixmap(planePic3);
    planeImage3->setObjectName("3");
    planeImage3->setGeometry((int)(750),(int)(190),(int) (80),(int)(80));

    planeLabels.push_back(planeImage);
    planeLabels.push_back(planeImage2);
    planeLabels.push_back(planeImage3);


}
void MainWindow::loadBlueShots(){

     blueShot1 = absPath+ blueShot1;
    blueShotPic.load(blueShot1);

    blueShotImage = new QLabel(this);
    blueShotImage->setPixmap(blueShotPic);
    blueShotImage->setObjectName("1");
    blueShotImage->setGeometry((int)(750),(int)(30),(int) (6),(int)(350));
    blueShotImage->setVisible(false);


    blueShotLabels.push_back(blueShotImage);

}
void MainWindow::loadRedShots(){

    redShot1 = absPath+ redShot1;
    redShotPic.load(redShot1);


    redShotImage = new QLabel(this);
    redShotImage->setPixmap(redShotPic);
    redShotImage->setObjectName("1");
    redShotImage->setGeometry((int)(750),(int)(30),(int) (6),(int)(350));
    redShotImage->setVisible(false);

    redShotLabels.push_back(redShotImage);


}
void MainWindow::startGame(){
    if(!running && planeImage->isVisible() && planeImage2->isVisible()&& planeImage3->isVisible()&& cannonImage->isVisible()&& cannonImage2->isVisible()&&cannonImage3->isVisible()){
        running = true;
        resetted = false;
        flyingAnimation();
        shootingPlane = getRandomPlane()->objectName().toInt();
        shootingCannon = getRandomCannon()->objectName().toInt();
        shootingPlaneDelay = getRandomPlaneShootDelay(shootingPlane);
        shootingCannonDelay = getRandomCannonShootDelay(shootingCannon);
        planeTimer = new Timer(this);
        planeTimer->setDelay(shootingPlaneDelay);
        connect(planeTimer, &Timer::finished, this, &MainWindow::planeTimerFinished);
        planeTimer->start();
        cannonTimer = new Timer(this);
        cannonTimer->setDelay(shootingCannonDelay);
        connect(cannonTimer, &Timer::finished, this, &MainWindow::cannonTimerFinished);
        cannonTimer->start();
    }
}

void MainWindow::resetGame(){
    running = false;
    resetted = true;
    redShotImage->setVisible(false);

    blueShotImage->setVisible(false);

    planeImage->setVisible(true);
    planeImage->setGeometry((int)(750),(int)(30),(int) (80),(int)(80));
    planeImage2->setVisible(true);
    planeImage2->setGeometry((int)(750),(int)(110),(int) (80),(int)(80));
    planeImage3->setVisible(true);
    planeImage3->setGeometry((int)(750),(int)(190),(int) (80),(int)(80));
    cannonImage->setVisible(true);
    cannonImage2->setVisible(true);
    cannonImage3->setVisible(true);

}

void MainWindow::shoot(){

}

void MainWindow::planeTimerFinished(){
    if(running){
        planeShootAnimation();
    }
}

void MainWindow::cannonTimerFinished(){
    if(running){
        cannonShootAnimation();
    }
}

void MainWindow::cannonShootAnimation(){
    int x=0, y=0, w=0, h=0;
    QLabel* shootingLaser;
     QParallelAnimationGroup *group2;
    int x1 = calculatePlaneX(1,shootingCannonDelay);
    int x2 = calculatePlaneX(2,shootingCannonDelay);
    int x3 = calculatePlaneX(3,shootingCannonDelay);
    if(shootingCannon == 1){
        if(planeImage->isVisible() && std::abs(170-x1 < 25)){
            shootingLaser = redShotImage;
            y= 450;
            h = 400;
            x = 170;
        }
        else if(planeImage2->isVisible()&& std::abs(170-x2 < 25)){
            shootingLaser = redShotImage;
            y= 450;
            h = 320;
            x = 170;
        }
        else if(planeImage3->isVisible()&& std::abs(170-x3 < 25)){
            shootingLaser = redShotImage;
            y= 450;
            h = 240;
            x = 170;
        }
        else{
            shootingLaser = redShotImage;
            y= 450;
            h = 400;
            x = 170;
        }

    }

    else if(shootingCannon == 2){
        if(planeImage->isVisible() && std::abs(400-x1 < 25)){
            shootingLaser = redShotImage;
            y= 450;
            h = 400;
            x = 400;
        }
        else if(planeImage2->isVisible()&& std::abs(400-x2 < 25)){
            shootingLaser = redShotImage;
            y= 450;
            h = 320;
            x = 400;
        }
        else if(planeImage3->isVisible()&& std::abs(400-x3 < 25)){
            shootingLaser = redShotImage;
            y= 450;
            h = 240;
            x = 400;
        }
        else{
            shootingLaser = redShotImage;
            y= 450;
            h = 400;
            x = 400;
        }

    }

    else if(shootingCannon == 3){
        if(planeImage->isVisible() && std::abs(600-x1 < 25)){
            shootingLaser = redShotImage;
            y= 450;
            h = 400;
            x = 600;
        }
        else if(planeImage2->isVisible()&& std::abs(600-x2 < 25)){
            shootingLaser = redShotImage;
            y= 450;
            h = 320;
            x = 600;
        }
        else if(planeImage3->isVisible()&& std::abs(600-x3 < 25)){
            shootingLaser = redShotImage;
            y= 450;
            h = 240;
            x = 600;
        }
        else{
            shootingLaser = redShotImage;
            y= 450;
            h = 400;
            x = 600;
        }

    }

    group2 = new QParallelAnimationGroup;
    anim = new QPropertyAnimation(shootingLaser, "geometry");
    anim->setDuration(300);
    anim->setStartValue(QRect(x, y,6,1));
    anim->setEndValue(QRect(x, y-h,6, h));
    group2->addAnimation(anim);
    shootingLaser->setVisible(true);

    connect(group2, SIGNAL(finished()), this, SLOT(cannonShootFinished()), Qt::UniqueConnection);
    group2->start(QAbstractAnimation::DeleteWhenStopped);
}

void MainWindow::planeShootAnimation(){
    int x=0, y=0, w=0, h=0;
        QLabel* shootingLaser;
         QParallelAnimationGroup *group2 ;
        if(shootingPlane == 1){
            shootingLaser = blueShotImage;
            y= 70;
            h = 460;
        }
        else if(shootingPlane == 2){
            shootingLaser = blueShotImage;
            y= 150;
            h = 380;
        }
        else{
            shootingLaser = blueShotImage;
            y= 240;
            h = 300;
        }
        x = calculatePlaneX(shootingPlane);

        group2 = new QParallelAnimationGroup;
        anim = new QPropertyAnimation(shootingLaser, "geometry");
        anim->setDuration(300);
        anim->setStartValue(QRect(x, y,6,1));
        anim->setEndValue(QRect(x, y,6, h));
        group2->addAnimation(anim);
        shootingLaser->setVisible(true);

        connect(group2, SIGNAL(finished()), this, SLOT(planeShootFinished()), Qt::UniqueConnection);
        group2->start(QAbstractAnimation::DeleteWhenStopped);

}
void MainWindow::planeShootFinished(){
    int x;
    blueShotImage->setVisible(false);

    x = calculatePlaneX(shootingPlane, shootingPlaneDelay);
    if(std::abs(x- 180)< 20){
        cannonImage->setVisible(false);
    }
    if(std::abs(x-410) <20){
        cannonImage2->setVisible(false);
    }
    if(std::abs(x-610) <20){
        cannonImage3->setVisible(false);
    }
}

void MainWindow::cannonShootFinished(){
    int x;

    redShotImage->setVisible(false);

    if(shootingCannon == 1){
        x = calculatePlaneX(1, shootingCannonDelay);
        if(std::abs(170-x) < 25){
            planeImage->setVisible(false);
        }
        x = calculatePlaneX(2,shootingCannonDelay);
        if(std::abs(x- 170)< 25){
            planeImage2->setVisible(false);
        }
        x = calculatePlaneX(3,shootingCannonDelay);
        if(std::abs(x- 170)< 25){
            planeImage3->setVisible(false);
        }
    }
    else if(shootingCannon ==2){
        x = calculatePlaneX(2, shootingCannonDelay);
        if(std::abs(x- 400)< 25){
            planeImage->setVisible(false);
        }
        x = calculatePlaneX(2,shootingCannonDelay);
        if(std::abs(x- 400)< 25){
            planeImage2->setVisible(false);
        }
        x = calculatePlaneX(3,shootingCannonDelay);
        if(std::abs(x- 400)< 25){
            planeImage3->setVisible(false);
        }
    }
    else if(shootingCannon ==3){
        x = calculatePlaneX(3, shootingCannonDelay);
        if(std::abs(x- 600)< 25){
            planeImage->setVisible(false);
        }
        x = calculatePlaneX(2,shootingCannonDelay);
        if(std::abs(x- 600)< 25){
            planeImage2->setVisible(false);
        }
        x = calculatePlaneX(3,shootingCannonDelay);
        if(std::abs(x- 600)< 25){
            planeImage3->setVisible(false);
        }
    }

}

int MainWindow::calculatePlaneX(int plane){
    int x=0;
    if(plane == 1){
        x = 750 - (shootingPlaneDelay * 830) / 10000;
    }
    else if(plane == 2){
        x = 750 - (shootingPlaneDelay * 830) / 8000;
    }
    else if(plane == 3){
        x = 750 - (shootingPlaneDelay * 830) / 6000;
    }
    return x;
}

int MainWindow::calculatePlaneX(int plane, int delay){
    int x=0;
    if(plane == 1){
        x = 750 -(delay * 830) / 10000;
    }
    else if(plane == 2){
        x = 750 - (delay * 830) / 8000;
    }
    else if(plane == 3){
        x = 750 - (delay * 830) / 6000;
    }
    return x;
}

void MainWindow::flyingAnimation(){
         QParallelAnimationGroup *group2 ;
        group2 = new QParallelAnimationGroup;
        anim = new QPropertyAnimation(planeLabels.at(0), "geometry");
        anim->setDuration(10000);
        anim->setStartValue(QRect(750, planeLabels.at(0)->y(),80,80));
        anim->setEndValue(QRect(-80, planeLabels.at(0)->y(),80, 80));

        anim2 = new QPropertyAnimation(planeLabels.at(1), "geometry");
        anim2->setDuration(8000);
        anim2->setStartValue(QRect(750, planeLabels.at(1)->y(),80,80));
        anim2->setEndValue(QRect(-80, planeLabels.at(1)->y(),80, 80));

        anim3 = new QPropertyAnimation(planeLabels.at(2), "geometry");
        anim3->setDuration(6000);
        anim3->setStartValue(QRect(750, planeLabels.at(2)->y(),80,80));
        anim3->setEndValue(QRect(-80, planeLabels.at(2)->y(),80, 80));

        group2->addAnimation(anim);
        group2->addAnimation(anim2);
        group2->addAnimation(anim3);

        connect(group2, SIGNAL(finished()), this, SLOT(flyingFinished()), Qt::UniqueConnection);
        group2->start(QAbstractAnimation::DeleteWhenStopped);


}
void MainWindow::flyingFinished(){

    int visiblePlanes = 0, visibleCannons = 0;
    QMessageBox* box= new QMessageBox();
    for(int i=0; i < planeLabels.size(); i++){
        if(planeLabels.at(i)->isVisible()){
            visiblePlanes++;
        }
    }
    for(int i=0; i < cannonLabels.size(); i++){
        if(cannonLabels.at(i)->isVisible()){
            visibleCannons++;
        }
    }

    if(running && visiblePlanes >0 && visibleCannons >0){

         flyingAnimation();
         shootingPlane = getRandomPlane()->objectName().toInt();
         shootingCannon = getRandomCannon()->objectName().toInt();
         shootingPlaneDelay = getRandomPlaneShootDelay(shootingPlane);
         shootingCannonDelay = getRandomCannonShootDelay(shootingCannon);
         planeTimer = new Timer(this);
         planeTimer->setDelay(shootingPlaneDelay);
         connect(planeTimer, &Timer::finished, this, &MainWindow::planeTimerFinished);
         planeTimer->start();
         cannonTimer = new Timer(this);
         cannonTimer->setDelay(shootingCannonDelay);
         connect(cannonTimer, &Timer::finished, this, &MainWindow::cannonTimerFinished);
         cannonTimer->start();


    }
    if(visiblePlanes ==0){

        box->setText("Cannons winner");
        box->setWindowModality(Qt::NonModal);
        box->open();
        box->show();
        running = false;
    }
    if(visibleCannons == 0){
        box->setText("Planes winner");
        box->setWindowModality(Qt::NonModal);
        box->open();
        box->show();
        running = false;

    }
    if(resetted){
        redShotImage->setVisible(false);
        blueShotImage->setVisible(false);
        planeImage->setVisible(true);
        planeImage->setGeometry((int)(750),(int)(30),(int) (80),(int)(80));
        planeImage2->setVisible(true);
        planeImage2->setGeometry((int)(750),(int)(110),(int) (80),(int)(80));
        planeImage3->setVisible(true);
        planeImage3->setGeometry((int)(750),(int)(190),(int) (80),(int)(80));
        cannonImage->setVisible(true);
        cannonImage2->setVisible(true);
        cannonImage3->setVisible(true);
    }
}
QLabel* MainWindow::getRandomPlane(){
    QLabel* plane =nullptr;
    int rand = -1;
    std::vector<QLabel*> visiblePlanes;
    for(unsigned int i=0; i < planeLabels.size(); i++){
        if(planeLabels.at(i)->isVisible()){
            visiblePlanes.push_back(planeLabels.at(i));
        }
    }
    if(visiblePlanes.size()==3){
        rand = Next(0,2);
        plane = visiblePlanes.at(rand);
    }
    else if(visiblePlanes.size()==2){
        rand = Next(0,1);
        plane = visiblePlanes.at(rand);
    }
    else if(visiblePlanes.size()==1){
        plane = visiblePlanes.at(0);
    }
    return plane;
}

QLabel* MainWindow::getRandomCannon(){
    QLabel* cannon = nullptr;
    int rand = -1;
    std::vector<QLabel*> visibleCannons;
    for(unsigned int i=0; i < cannonLabels.size(); i++){
        if(cannonLabels.at(i)->isVisible()){
            visibleCannons.push_back(cannonLabels.at(i));
        }
    }
    if(visibleCannons.size()==3){
        rand = Next(0,2);
        cannon = visibleCannons.at(rand);
    }
    else if(visibleCannons.size()==2){
        rand = Next(0,1);
        cannon = visibleCannons.at(rand);
    }
    else if(visibleCannons.size()==1){
        cannon = visibleCannons.at(0);
    }
    return cannon;
}

int MainWindow::getRandomPlaneShootDelay(int planeNumber){
    int random1 = -1, random2 = -1;
    int delay =0;
    if(planeNumber == 1){
        random1 = Next(1,8);
        random2 = Next(0,9);
        delay = 1000*random1+ 100* random2;
    }
    else if(planeNumber == 2){
        random1 = Next(1,7);
        random2 = Next(0,9);
        delay = 1000*random1+ 100* random2;
    }
    else if(planeNumber == 3){
        random1 = Next(1,5);
        random2 = Next(0,9);
        delay = 1000*random1+ 100* random2;
    }
    return delay;
}

int MainWindow::getRandomCannonShootDelay(int cannonNumber){
    int random1 = -1, random2 = -1;
    int delay =0;
    if(cannonNumber == 1){
        random1 = Next(3,7);
        random2 = Next(0,9);
        delay = 1000*random1+ 100* random2;
    }
    else if(cannonNumber == 2){
        random1 = Next(2,6);
        random2 = Next(0,9);
        delay = 1000*random1+ 100* random2;
    }
    else if(cannonNumber == 3){
        random1 = Next(1,3);
        random2 = Next(0,9);
        delay = 1000*random1+ 100* random2;
    }
    return delay;
}

void MainWindow::generateDelays(){
    delays[0] =0;
    delays[1] = Next(1,5)*1000;
    delays[2] = Next(1,5)*1000;
}
int MainWindow::Next(int minValue, int maxValue) {
    int value = minValue + (rand() % static_cast<int>(maxValue - minValue + 1));
    return value;
}
